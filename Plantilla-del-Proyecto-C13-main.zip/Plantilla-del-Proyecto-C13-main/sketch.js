var garden,rabbit;
var gardenImg,rabbitImg;
let red, redImg
let apple, appleImg;
let orangeleaf, orangeImg;
let select_sprites = 1;// Math.round(random(1,3))

function preload(){
  gardenImg = loadImage("garden.png");
  rabbitImg = loadImage("rabbit.png");
  appleImg = loadImage("apple.png");
  orangeImg = loadImage("orangeLeaf.png");
  redImg = loadImage("redImage.png"); 
}

function setup(){
  
  createCanvas(400,400);
  
  // Mover el fondo
  garden=createSprite(200,200);
  garden.addImage(gardenImg);
  
  // Crear imagen de red (hoja)
  red = createSprite(200,10,20,10)
  red.addImage(redImg)
  red.scale = 0.05
  
  // Crear sprite de rabbit (conejo)
  rabbit = createSprite(180,340,30,30);
  rabbit.scale =0.09;
  rabbit.addImage(rabbitImg);
}


function draw() {
  background(0);

  edges= createEdgeSprites();
  rabbit.collide(edges);
rabbit.x = World.mouseX;
  randomselect();
  drawSprites();
}

function createApples(){
  apple = createSprite(random(50,350),40,10,10)
  apple.addImage(appleImg);
  apple.scale = 0.07
  apple.velocityY = 3;
  apple.lifetime = 150;
}

function createreds(){
  red = createSprite(random(50,350),40,10,10)
  red.addImage(redImg);
  red.scale = 0.06
  red.velocityY = 3;
  red.lifetime = 150;
}

function createorangeleafs(){
  orangeleaf = createSprite(random(50,350),40,10,10)
  orangeleaf.addImage(orangeImg);
  orangeleaf.scale = 0.08
  orangeleaf.velocityY = 3;
  orangeleaf.lifetime = 150
}

function randomselect() {
  select_sprites = Math.round(random(0.5, 3.4));

  if (frameCount % 80 === 0){
    if(select_sprites == 1 ){
      createApples();
    }
    if(select_sprites == 2 ){
      createorangeleafs();
    }
    if(select_sprites == 3 ){
      createreds();
    }
  }
}